export interface MessageModel {
  text: string;
}
