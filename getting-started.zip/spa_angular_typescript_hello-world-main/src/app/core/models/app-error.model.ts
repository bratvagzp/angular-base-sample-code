export interface AppErrorModel {
  message: string;
}
