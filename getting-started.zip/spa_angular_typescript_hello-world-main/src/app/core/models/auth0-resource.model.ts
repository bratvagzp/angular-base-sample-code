export interface Auth0ResourceModel {
  path: string;
  label: string;
}
